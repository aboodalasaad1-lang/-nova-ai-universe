import type { Metadata, Viewport } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Toaster } from "react-hot-toast"
import { AuthProvider } from "@/components/providers/auth-provider"
import { ThemeProvider } from "@/components/providers/theme-provider"

const inter = Inter({ 
  subsets: ["latin"],
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: "Nova AI Universe - Your Personal AI Companion",
  description: "Experience the future with Nova AI Universe. Your personal AI companion, creative tools, and future life simulations all in one place.",
  keywords: ["AI", "companion", "chatbot", "future", "creativity", "productivity"],
  authors: [{ name: "Nova AI Universe" }],
  openGraph: {
    title: "Nova AI Universe",
    description: "Your Personal AI Companion for the Future",
    type: "website",
  },
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#0A0A0F",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <ThemeProvider>
          <AuthProvider>
            {children}
            <Toaster 
              position="top-right"
              toastOptions={{
                style: {
                  background: "rgba(10, 10, 15, 0.95)",
                  border: "1px solid rgba(255, 255, 255, 0.1)",
                  color: "#fff",
                  backdropFilter: "blur(10px)",
                },
              }}
            />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
