"use client"

import { motion } from "framer-motion"
import { Sparkles, Zap, Brain, Rocket, ChevronRight, Star, Users, Shield } from "lucide-react"
import Link from "next/link"
import { FloatingParticles } from "@/components/animations/floating-particles"
import { Robot3D } from "@/components/3d/robot-3d"

export default function LandingPage() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-nova-dark">
      <FloatingParticles />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b-0">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-nova-gradient flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">Nova AI</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-sm text-white/70 hover:text-white transition-colors">Features</Link>
            <Link href="#pricing" className="text-sm text-white/70 hover:text-white transition-colors">Pricing</Link>
            <Link href="#experts" className="text-sm text-white/70 hover:text-white transition-colors">Experts</Link>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/login" className="text-sm text-white/70 hover:text-white transition-colors">Sign In</Link>
            <Link href="/register" className="btn-primary text-sm">Get Started</Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-sm text-white/80">AI Universe v2.0 is live</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
              Meet Your{" "}
              <span className="gradient-text">Future</span>
              <br />
              AI Companion
            </h1>

            <p className="text-lg text-white/60 mb-8 max-w-lg">
              Nova AI Universe is more than a chatbot. It is your personal AI companion 
              that evolves, remembers, and grows with you. Experience the future of 
              human-AI interaction.
            </p>

            <div className="flex flex-wrap gap-4 mb-12">
              <Link href="/register" className="btn-primary flex items-center gap-2">
                Start Your Journey
                <ChevronRight className="w-4 h-4" />
              </Link>
              <Link href="/login" className="btn-secondary flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Try Demo
              </Link>
            </div>

            <div className="flex items-center gap-8">
              <div className="flex -space-x-3">
                {[1,2,3,4].map((i) => (
                  <div key={i} className="w-10 h-10 rounded-full bg-gradient-to-br from-nova-blue to-nova-purple border-2 border-nova-dark" />
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1 mb-1">
                  {[1,2,3,4,5].map((i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-white/60">Trusted by 50,000+ users</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="relative h-[500px] lg:h-[600px]"
          >
            <Robot3D />

            {/* Floating Cards */}
            <motion.div
              animate={{ y: [0, -20, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute top-10 left-0 glass rounded-2xl p-4 max-w-[200px]"
            >
              <Brain className="w-6 h-6 text-nova-blue mb-2" />
              <p className="text-sm font-medium">AI Memory</p>
              <p className="text-xs text-white/60">Remembers everything about you</p>
            </motion.div>

            <motion.div
              animate={{ y: [0, 20, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute bottom-20 right-0 glass rounded-2xl p-4 max-w-[200px]"
            >
              <Rocket className="w-6 h-6 text-nova-pink mb-2" />
              <p className="text-sm font-medium">Evolution</p>
              <p className="text-xs text-white/60">Grows with every interaction</p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Everything You Need for{" "}
              <span className="gradient-text">Tomorrow</span>
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto">
              A complete AI ecosystem designed to enhance every aspect of your life
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card-glass group cursor-pointer"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-white/60 text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="glass rounded-3xl p-8 md:p-12">
            <div className="grid md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-4xl md:text-5xl font-bold gradient-text mb-2">
                    {stat.value}
                  </div>
                  <div className="text-white/60">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass rounded-3xl p-12 relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-nova-gradient opacity-10" />
            <div className="relative z-10">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">
                Ready to Meet Your{" "}
                <span className="gradient-text">Future?</span>
              </h2>
              <p className="text-white/60 mb-8 max-w-xl mx-auto">
                Join thousands of users who have already started their journey 
                with Nova AI Universe. Your personal AI companion awaits.
              </p>
              <Link href="/register" className="btn-primary inline-flex items-center gap-2 text-lg px-8 py-4">
                <Sparkles className="w-5 h-5" />
                Create Your Universe
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-nova-gradient flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold gradient-text">Nova AI Universe</span>
            </div>
            <div className="flex items-center gap-6 text-sm text-white/40">
              <Link href="#" className="hover:text-white transition-colors">Privacy</Link>
              <Link href="#" className="hover:text-white transition-colors">Terms</Link>
              <Link href="#" className="hover:text-white transition-colors">Contact</Link>
            </div>
            <p className="text-sm text-white/40"> 2026 Nova AI Universe. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

const features = [
  {
    title: "AI Companion",
    description: "Your personal AI that evolves, remembers, and grows with you over time.",
    icon: Brain,
    gradient: "from-nova-blue to-blue-600",
  },
  {
    title: "Future Self",
    description: "Visualize your future with AI-generated images and stories.",
    icon: Rocket,
    gradient: "from-nova-pink to-pink-600",
  },
  {
    title: "Video Generator",
    description: "Create stunning videos from text prompts for any platform.",
    icon: Zap,
    gradient: "from-nova-purple to-purple-600",
  },
  {
    title: "Image Generator",
    description: "Generate realistic photos, anime art, and professional content.",
    icon: Sparkles,
    gradient: "from-orange-400 to-red-500",
  },
  {
    title: "AI Experts",
    description: "Consult with specialized AI experts in any field.",
    icon: Users,
    gradient: "from-green-400 to-emerald-600",
  },
  {
    title: "Secure & Private",
    description: "End-to-end encryption with complete data privacy.",
    icon: Shield,
    gradient: "from-cyan-400 to-blue-500",
  },
]

const stats = [
  { value: "50K+", label: "Active Users" },
  { value: "10M+", label: "Messages" },
  { value: "99.9%", label: "Uptime" },
  { value: "4.9", label: "Rating" },
]
