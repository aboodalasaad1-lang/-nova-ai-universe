"use client"

import { motion } from "framer-motion"
import { Users, Star, MessageSquare, Stethoscope, Scale, BookOpen, Dumbbell, TrendingUp, Code, Briefcase } from "lucide-react"

const experts = [
  { id: "doctor", name: "Dr. AI", title: "Medical Expert", icon: Stethoscope, color: "from-red-500 to-pink-500", specialty: "Health & Wellness", rating: 4.9, conversations: 12500 },
  { id: "lawyer", name: "Legal AI", title: "Legal Advisor", icon: Scale, color: "from-blue-500 to-indigo-500", specialty: "Law & Contracts", rating: 4.8, conversations: 8900 },
  { id: "teacher", name: "Professor AI", title: "Educational Tutor", icon: BookOpen, color: "from-green-500 to-emerald-500", specialty: "Learning & Education", rating: 4.9, conversations: 15200 },
  { id: "fitness", name: "Coach AI", title: "Fitness Trainer", icon: Dumbbell, color: "from-orange-500 to-amber-500", specialty: "Fitness & Nutrition", rating: 4.7, conversations: 9800 },
  { id: "marketing", name: "Marketing AI", title: "Marketing Expert", icon: TrendingUp, color: "from-purple-500 to-violet-500", specialty: "Marketing & Growth", rating: 4.8, conversations: 11200 },
  { id: "programmer", name: "Dev AI", title: "Programming Expert", icon: Code, color: "from-cyan-500 to-blue-500", specialty: "Coding & Development", rating: 4.9, conversations: 18500 },
  { id: "career", name: "Career AI", title: "Career Coach", icon: Briefcase, color: "from-yellow-500 to-orange-500", specialty: "Career Development", rating: 4.8, conversations: 7600 },
]

export default function ExpertsPage() {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl font-bold mb-2">AI Experts Marketplace</h1>
        <p className="text-white/60">Consult with specialized AI professionals</p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {experts.map((expert, i) => (
          <motion.div
            key={expert.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="card-glass group cursor-pointer"
          >
            <div className="flex items-start gap-4 mb-4">
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${expert.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                <expert.icon className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">{expert.name}</h3>
                <p className="text-sm text-white/60">{expert.title}</p>
              </div>
            </div>

            <p className="text-sm text-white/60 mb-4">{expert.specialty}</p>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span className="text-sm font-medium">{expert.rating}</span>
              </div>
              <div className="flex items-center gap-1 text-white/40">
                <MessageSquare className="w-4 h-4" />
                <span className="text-sm">{expert.conversations.toLocaleString()}</span>
              </div>
            </div>

            <button className="w-full mt-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-sm font-medium">
              Start Consultation
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
