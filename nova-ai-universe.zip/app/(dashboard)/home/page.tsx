"use client"

import { motion } from "framer-motion"
import { Bot, MessageSquare, Sparkles, Zap, TrendingUp, Clock } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-8 relative overflow-hidden"
      >
        <div className="relative z-10">
          <h1 className="text-3xl font-bold mb-2">
            Welcome back, <span className="gradient-text">Explorer</span>!
          </h1>
          <p className="text-white/60">
            Your AI companion has missed you. Ready to continue your journey?
          </p>
        </div>
      </motion.div>

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: "Level", value: "12", icon: Zap, color: "text-yellow-400" },
          { label: "XP", value: "3,450", icon: TrendingUp, color: "text-green-400" },
          { label: "Streak", value: "7 days", icon: Clock, color: "text-orange-400" },
          { label: "Messages", value: "1,234", icon: MessageSquare, color: "text-nova-blue" },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="card-glass"
          >
            <stat.icon className={`w-6 h-6 ${stat.color} mb-2`} />
            <p className="text-2xl font-bold">{stat.value}</p>
            <p className="text-sm text-white/60">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { title: "Start Chat", desc: "Talk with your AI companion", icon: Bot, href: "/chat" },
          { title: "Generate Image", desc: "Create stunning visuals", icon: Sparkles, href: "/image-generator" },
          { title: "Future Self", desc: "See your future", icon: Zap, href: "/future-self" },
        ].map((action, i) => (
          <motion.div
            key={action.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 + i * 0.1 }}
          >
            <Link href={action.href} className="card-glass group cursor-pointer block">
              <action.icon className="w-8 h-8 text-nova-blue mb-4 group-hover:scale-110 transition-transform" />
              <h3 className="font-semibold mb-1">{action.title}</h3>
              <p className="text-sm text-white/60">{action.desc}</p>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
