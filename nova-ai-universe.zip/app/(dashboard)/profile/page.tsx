"use client"

import { motion } from "framer-motion"
import { User, Zap, Trophy, Clock, Star, TrendingUp } from "lucide-react"

export default function ProfilePage() {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="card-glass"
      >
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 rounded-2xl bg-nova-gradient flex items-center justify-center">
            <User className="w-12 h-12 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">John Doe</h1>
            <p className="text-white/60">Explorer Level 12</p>
            <div className="flex items-center gap-4 mt-2">
              <span className="text-sm text-nova-blue">@johndoe</span>
              <span className="text-sm text-white/40">Joined Jan 2026</span>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { label: "Total XP", value: "3,450", icon: Zap, color: "text-yellow-400" },
          { label: "Achievements", value: "24", icon: Trophy, color: "text-nova-blue" },
          { label: "Streak", value: "7 days", icon: Clock, color: "text-orange-400" },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="card-glass"
          >
            <stat.icon className={`w-6 h-6 ${stat.color} mb-2`} />
            <p className="text-2xl font-bold">{stat.value}</p>
            <p className="text-sm text-white/60">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="card-glass"
        >
          <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {[
              { action: "Generated an image", time: "2 hours ago", icon: Star },
              { action: "Completed daily mission", time: "5 hours ago", icon: Trophy },
              { action: "Chat with Nova AI", time: "1 day ago", icon: Zap },
            ].map((activity, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
                <activity.icon className="w-4 h-4 text-nova-blue" />
                <div className="flex-1">
                  <p className="text-sm">{activity.action}</p>
                  <p className="text-xs text-white/40">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="card-glass"
        >
          <h3 className="text-lg font-semibold mb-4">Skills Progress</h3>
          <div className="space-y-4">
            {[
              { skill: "Creativity", progress: 85 },
              { skill: "Productivity", progress: 72 },
              { skill: "Learning", progress: 90 },
              { skill: "Social", progress: 65 },
            ].map((skill) => (
              <div key={skill.skill}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm">{skill.skill}</span>
                  <span className="text-sm text-white/60">{skill.progress}%</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${skill.progress}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className="h-full rounded-full bg-nova-gradient"
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  )
}
