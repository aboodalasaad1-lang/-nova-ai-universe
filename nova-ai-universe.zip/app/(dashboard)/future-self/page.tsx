"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Upload, Sparkles, Wand2, Clock, Star } from "lucide-react"

const scenarios = [
  { id: "billionaire", name: "Billionaire", icon: "💰" },
  { id: "ceo", name: "CEO", icon: "👔" },
  { id: "football", name: "Football Star", icon: "⚽" },
  { id: "astronaut", name: "Astronaut", icon: "🚀" },
  { id: "movie", name: "Movie Star", icon: "🎬" },
  { id: "warrior", name: "Warrior", icon: "⚔️" },
  { id: "anime", name: "Anime Character", icon: "🎌" },
  { id: "superhero", name: "Superhero", icon: "🦸" },
]

export default function FutureSelfPage() {
  const [selectedScenario, setSelectedScenario] = useState("")
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [generating, setGenerating] = useState(false)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => setUploadedImage(reader.result as string)
      reader.readAsDataURL(file)
    }
  }

  const handleGenerate = () => {
    setGenerating(true)
    setTimeout(() => setGenerating(false), 3000)
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl font-bold mb-2">Future Self</h1>
        <p className="text-white/60">See yourself in the future</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="card-glass"
      >
        <h3 className="text-lg font-semibold mb-4">Upload Your Photo</h3>
        <div className="border-2 border-dashed border-white/20 rounded-2xl p-8 text-center hover:border-nova-blue/50 transition-colors cursor-pointer">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
            id="photo-upload"
          />
          <label htmlFor="photo-upload" className="cursor-pointer">
            {uploadedImage ? (
              <img src={uploadedImage} alt="Uploaded" className="w-32 h-32 rounded-2xl mx-auto object-cover" />
            ) : (
              <>
                <Upload className="w-12 h-12 text-white/40 mx-auto mb-4" />
                <p className="text-white/60">Click to upload or drag and drop</p>
                <p className="text-sm text-white/40 mt-2">PNG, JPG up to 10MB</p>
              </>
            )}
          </label>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <h3 className="text-lg font-semibold mb-4">Choose Your Future</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {scenarios.map((scenario) => (
            <motion.button
              key={scenario.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedScenario(scenario.id)}
              className={`card-glass text-center py-6 ${
                selectedScenario === scenario.id
                  ? "border-2 border-nova-blue ring-2 ring-nova-blue/20"
                  : ""
              }`}
            >
              <span className="text-4xl mb-2 block">{scenario.icon}</span>
              <p className="font-medium">{scenario.name}</p>
            </motion.button>
          ))}
        </div>
      </motion.div>

      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        onClick={handleGenerate}
        disabled={!uploadedImage || !selectedScenario || generating}
        className="btn-primary w-full flex items-center justify-center gap-2 py-4 text-lg disabled:opacity-50"
      >
        {generating ? (
          <>
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Generating Your Future...
          </>
        ) : (
          <>
            <Wand2 className="w-5 h-5" />
            Generate Future Self
          </>
        )}
      </motion.button>

      {!generating && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid md:grid-cols-3 gap-4"
        >
          <div className="card-glass">
            <Clock className="w-6 h-6 text-nova-blue mb-2" />
            <p className="font-semibold">Timeline</p>
            <p className="text-sm text-white/60">Interactive future timeline</p>
          </div>
          <div className="card-glass">
            <Star className="w-6 h-6 text-nova-pink mb-2" />
            <p className="font-semibold">Story</p>
            <p className="text-sm text-white/60">Personalized narrative</p>
          </div>
          <div className="card-glass">
            <Sparkles className="w-6 h-6 text-nova-purple mb-2" />
            <p className="font-semibold">Video</p>
            <p className="text-sm text-white/60">Cinematic experience</p>
          </div>
        </motion.div>
      )}
    </div>
  )
}
