"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Video, Wand2, Play } from "lucide-react"

const formats = [
  { id: "tiktok", name: "TikTok" },
  { id: "reels", name: "Instagram Reels" },
  { id: "shorts", name: "YouTube Shorts" },
  { id: "marketing", name: "Marketing" },
  { id: "trailer", name: "Cinematic Trailer" },
]

export default function VideoGeneratorPage() {
  const [prompt, setPrompt] = useState("")
  const [selectedFormat, setSelectedFormat] = useState("tiktok")
  const [generating, setGenerating] = useState(false)

  const handleGenerate = () => {
    if (!prompt.trim()) return
    setGenerating(true)
    setTimeout(() => setGenerating(false), 5000)
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl font-bold mb-2">AI Video Generator</h1>
        <p className="text-white/60">Create videos from text prompts</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="card-glass"
      >
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe the video you want to create..."
          className="w-full bg-transparent border-none outline-none text-white placeholder:text-white/40 resize-none h-24"
        />
        <div className="flex items-center justify-between mt-4">
          <div className="flex gap-2 flex-wrap">
            {formats.map((format) => (
              <button
                key={format.id}
                onClick={() => setSelectedFormat(format.id)}
                className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                  selectedFormat === format.id
                    ? "bg-white/20 text-white"
                    : "text-white/60 hover:text-white hover:bg-white/5"
                }`}
              >
                {format.name}
              </button>
            ))}
          </div>
          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || generating}
            className="btn-primary flex items-center gap-2"
          >
            {generating ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Video className="w-4 h-4" />
            )}
            Generate Video
          </button>
        </div>
      </motion.div>

      {generating && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="card-glass p-12 text-center"
        >
          <div className="w-16 h-16 rounded-full bg-nova-gradient flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Play className="w-8 h-8 text-white" />
          </div>
          <p className="text-lg font-semibold">Generating Your Video...</p>
          <p className="text-white/60">This may take a few moments</p>
        </motion.div>
      )}
    </div>
  )
}
