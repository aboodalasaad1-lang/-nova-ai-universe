"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Wand2, Download, Share2, ImageIcon } from "lucide-react"

const styles = [
  { id: "realistic", name: "Realistic" },
  { id: "anime", name: "Anime" },
  { id: "product", name: "Product" },
  { id: "social", name: "Social Media" },
  { id: "marketing", name: "Marketing" },
  { id: "headshot", name: "Headshot" },
]

export default function ImageGeneratorPage() {
  const [prompt, setPrompt] = useState("")
  const [selectedStyle, setSelectedStyle] = useState("realistic")
  const [generating, setGenerating] = useState(false)
  const [generatedImages, setGeneratedImages] = useState<string[]>([])

  const handleGenerate = () => {
    if (!prompt.trim()) return
    setGenerating(true)
    setTimeout(() => {
      setGeneratedImages(["1", "2", "3"])
      setGenerating(false)
    }, 3000)
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl font-bold mb-2">AI Image Generator</h1>
        <p className="text-white/60">Create stunning visuals from text</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="card-glass"
      >
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe the image you want to create..."
          className="w-full bg-transparent border-none outline-none text-white placeholder:text-white/40 resize-none h-24"
        />
        <div className="flex items-center justify-between mt-4">
          <div className="flex gap-2 flex-wrap">
            {styles.map((style) => (
              <button
                key={style.id}
                onClick={() => setSelectedStyle(style.id)}
                className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                  selectedStyle === style.id
                    ? "bg-white/20 text-white"
                    : "text-white/60 hover:text-white hover:bg-white/5"
                }`}
              >
                {style.name}
              </button>
            ))}
          </div>
          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || generating}
            className="btn-primary flex items-center gap-2"
          >
            {generating ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Wand2 className="w-4 h-4" />
            )}
            Generate
          </button>
        </div>
      </motion.div>

      {generatedImages.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid md:grid-cols-3 gap-4"
        >
          {generatedImages.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="card-glass p-0 overflow-hidden group"
            >
              <div className="aspect-square bg-gradient-to-br from-nova-blue/20 to-nova-purple/20 flex items-center justify-center">
                <ImageIcon className="w-16 h-16 text-white/20" />
              </div>
              <div className="p-4 flex items-center justify-between">
                <span className="text-sm text-white/60">Image {i + 1}</span>
                <div className="flex gap-2">
                  <button className="p-2 rounded-lg hover:bg-white/5 transition-colors">
                    <Download className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-lg hover:bg-white/5 transition-colors">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  )
}
