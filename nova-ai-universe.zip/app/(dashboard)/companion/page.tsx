"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Bot, Heart, Star, Zap, Trophy, ChevronRight } from "lucide-react"

export default function CompanionPage() {
  const [selectedCompanion, setSelectedCompanion] = useState("nova")

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl font-bold mb-2">Your AI Companion</h1>
        <p className="text-white/60">Choose and evolve your personal AI friend</p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {[
          { id: "nova", name: "Nova", color: "blue", desc: "Professional & Motivational" },
          { id: "luna", name: "Luna", color: "pink", desc: "Warm & Supportive" },
        ].map((companion) => (
          <motion.button
            key={companion.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setSelectedCompanion(companion.id)}
            className={`card-glass relative overflow-hidden ${
              selectedCompanion === companion.id
                ? "border-2 border-nova-blue ring-2 ring-nova-blue/20"
                : ""
            }`}
          >
            <div className="flex items-center gap-4">
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br from-nova-${companion.color} to-${companion.color}-600 flex items-center justify-center`}>
                <Bot className="w-8 h-8 text-white" />
              </div>
              <div className="text-left">
                <h3 className="text-xl font-bold">{companion.name}</h3>
                <p className="text-white/60">{companion.desc}</p>
              </div>
            </div>
            {selectedCompanion === companion.id && (
              <motion.div
                layoutId="selected"
                className="absolute top-4 right-4 w-6 h-6 rounded-full bg-nova-blue flex items-center justify-center"
              >
                <Star className="w-4 h-4 text-white fill-white" />
              </motion.div>
            )}
          </motion.button>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { label: "Level", value: "12", icon: Zap, color: "text-yellow-400" },
          { label: "Affection", value: "85%", icon: Heart, color: "text-red-400" },
          { label: "Achievements", value: "24", icon: Trophy, color: "text-nova-blue" },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="card-glass"
          >
            <stat.icon className={`w-6 h-6 ${stat.color} mb-2`} />
            <p className="text-2xl font-bold">{stat.value}</p>
            <p className="text-sm text-white/60">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="glass rounded-2xl p-6">
        <h3 className="text-xl font-semibold mb-4">Evolution Path</h3>
        <div className="flex items-center gap-4">
          {[1, 10, 25, 50, 100].map((level, i) => (
            <div key={level} className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                12 >= level ? "bg-nova-gradient" : "bg-white/10"
              }`}>
                <span className="text-sm font-bold">{level}</span>
              </div>
              {i < 4 && <ChevronRight className="w-4 h-4 text-white/30" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
