export interface User {
  id: string
  email: string
  name: string | null
  image: string | null
  companion: "nova" | "luna" | null
  level: number
  xp: number
  streak: number
  lastActive: Date
  plan: "free" | "pro" | "premium" | "ultimate"
  createdAt: Date
  updatedAt: Date
}

export interface Companion {
  id: string
  name: string
  gender: "male" | "female"
  color: string
  personality: string
  voice: string
  level: number
  evolution: number
  animations: string[]
  userId: string
}

export interface ChatMessage {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  attachments?: Attachment[]
  metadata?: Record<string, any>
}

export interface Attachment {
  id: string
  type: "image" | "document" | "audio" | "video"
  url: string
  name: string
  size: number
}

export interface Memory {
  id: string
  key: string
  value: string
  category: string
  importance: number
  createdAt: Date
  updatedAt: Date
}

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  xpReward: number
  unlockedAt?: Date
  progress: number
  maxProgress: number
}

export interface Mission {
  id: string
  title: string
  description: string
  type: "daily" | "weekly" | "special"
  xpReward: number
  completed: boolean
  progress: number
  maxProgress: number
  expiresAt?: Date
}

export interface GeneratedContent {
  id: string
  type: "image" | "video" | "story"
  prompt: string
  url: string
  thumbnail?: string
  createdAt: Date
  userId: string
}

export interface Expert {
  id: string
  name: string
  title: string
  avatar: string
  color: string
  specialty: string
  description: string
  rating: number
  conversations: number
}

export interface SubscriptionPlan {
  id: string
  name: string
  price: number
  interval: "month" | "year"
  features: string[]
  popular?: boolean
  stripePriceId: string
}

export interface Referral {
  id: string
  code: string
  referrals: number
  credits: number
  earnings: number
}

export interface Notification {
  id: string
  title: string
  message: string
  type: "achievement" | "mission" | "system" | "social"
  read: boolean
  createdAt: Date
}

export interface AdminStats {
  totalUsers: number
  activeUsers: number
  newUsersToday: number
  revenue: number
  subscriptions: {
    free: number
    pro: number
    premium: number
    ultimate: number
  }
  aiUsage: {
    chat: number
    image: number
    video: number
  }
}
