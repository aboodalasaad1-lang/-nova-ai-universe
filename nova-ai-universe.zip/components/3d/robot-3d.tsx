"use client"

import { Suspense, useRef } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Environment, Float, MeshDistortMaterial } from "@react-three/drei"
import * as THREE from "three"

function RobotBody() {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.1
      meshRef.current.position.y = Math.sin(state.clock.elapsedTime * 1) * 0.1
    }
  })

  return (
    <group ref={meshRef}>
      {/* Head */}
      <mesh position={[0, 1.5, 0]}>
        <boxGeometry args={[0.8, 0.7, 0.6]} />
        <MeshDistortMaterial
          color="#00D4FF"
          roughness={0.1}
          metalness={0.8}
          distort={0.1}
          speed={2}
        />
      </mesh>

      {/* Eyes */}
      <mesh position={[-0.2, 1.6, 0.31]}>
        <sphereGeometry args={[0.08, 16, 16]} />
        <meshStandardMaterial color="#00FF88" emissive="#00FF88" emissiveIntensity={2} />
      </mesh>
      <mesh position={[0.2, 1.6, 0.31]}>
        <sphereGeometry args={[0.08, 16, 16]} />
        <meshStandardMaterial color="#00FF88" emissive="#00FF88" emissiveIntensity={2} />
      </mesh>

      {/* Body */}
      <mesh position={[0, 0.5, 0]}>
        <boxGeometry args={[1, 1.2, 0.7]} />
        <MeshDistortMaterial
          color="#1a1a2e"
          roughness={0.2}
          metalness={0.9}
          distort={0.05}
          speed={1}
        />
      </mesh>

      {/* Chest Light */}
      <mesh position={[0, 0.7, 0.36]}>
        <circleGeometry args={[0.15, 32]} />
        <meshStandardMaterial color="#00D4FF" emissive="#00D4FF" emissiveIntensity={3} />
      </mesh>

      {/* Arms */}
      <mesh position={[-0.7, 0.5, 0]}>
        <cylinderGeometry args={[0.1, 0.08, 1, 16]} />
        <meshStandardMaterial color="#2a2a3e" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[0.7, 0.5, 0]}>
        <cylinderGeometry args={[0.1, 0.08, 1, 16]} />
        <meshStandardMaterial color="#2a2a3e" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Legs */}
      <mesh position={[-0.3, -0.5, 0]}>
        <cylinderGeometry args={[0.12, 0.1, 0.8, 16]} />
        <meshStandardMaterial color="#2a2a3e" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[0.3, -0.5, 0]}>
        <cylinderGeometry args={[0.12, 0.1, 0.8, 16]} />
        <meshStandardMaterial color="#2a2a3e" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Antenna */}
      <mesh position={[0, 2.1, 0]}>
        <cylinderGeometry args={[0.02, 0.02, 0.4, 8]} />
        <meshStandardMaterial color="#00D4FF" emissive="#00D4FF" emissiveIntensity={1} />
      </mesh>
      <mesh position={[0, 2.3, 0]}>
        <sphereGeometry args={[0.05, 16, 16]} />
        <meshStandardMaterial color="#00D4FF" emissive="#00D4FF" emissiveIntensity={2} />
      </mesh>
    </group>
  )
}

function FloatingRings() {
  const groupRef = useRef<THREE.Group>(null)

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.x = state.clock.elapsedTime * 0.2
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.3
    }
  })

  return (
    <group ref={groupRef}>
      {[0.5, 1, 1.5].map((radius, i) => (
        <mesh key={i} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[radius, 0.01, 16, 100]} />
          <meshStandardMaterial
            color="#00D4FF"
            transparent
            opacity={0.3 - i * 0.1}
            emissive="#00D4FF"
            emissiveIntensity={0.5}
          />
        </mesh>
      ))}
    </group>
  )
}

export function Robot3D() {
  return (
    <div className="w-full h-full">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.3} />
          <pointLight position={[10, 10, 10]} intensity={1} />
          <pointLight position={[-10, -10, -10]} intensity={0.5} color="#FF6B9D" />
          <spotLight position={[0, 10, 0]} angle={0.3} penumbra={1} intensity={1} />

          <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
            <RobotBody />
          </Float>

          <FloatingRings />

          <Environment preset="city" />
          <OrbitControls
            enableZoom={false}
            enablePan={false}
            autoRotate
            autoRotateSpeed={0.5}
            minPolarAngle={Math.PI / 3}
            maxPolarAngle={Math.PI / 1.5}
          />
        </Suspense>
      </Canvas>
    </div>
  )
}
