"use client"

import { Bell, Search, User } from "lucide-react"
import { useAppStore } from "@/lib/store"

export function DashboardHeader() {
  const notifications = useAppStore((s) => s.notifications)

  return (
    <header className="h-16 glass border-b border-white/5 flex items-center justify-between px-6">
      <div className="flex items-center gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
          <input
            type="text"
            placeholder="Search..."
            className="input-glass w-64 pl-10 text-sm"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="relative p-2 rounded-xl hover:bg-white/5 transition-colors">
          <Bell className="w-5 h-5 text-white/60" />
          {notifications.filter((n) => !n.read).length > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-nova-pink rounded-full" />
          )}
        </button>

        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-nova-gradient flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
        </div>
      </div>
    </header>
  )
}
