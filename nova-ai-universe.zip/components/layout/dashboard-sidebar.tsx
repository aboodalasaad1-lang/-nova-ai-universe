"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion } from "framer-motion"
import {
  Home, MessageSquare, Bot, Sparkles, Video, Image,
  Users, Trophy, Settings, CreditCard, LogOut
} from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  { href: "/home", icon: Home, label: "Home" },
  { href: "/chat", icon: MessageSquare, label: "Chat" },
  { href: "/companion", icon: Bot, label: "Companion" },
  { href: "/future-self", icon: Sparkles, label: "Future Self" },
  { href: "/video-generator", icon: Video, label: "Video" },
  { href: "/image-generator", icon: Image, label: "Image" },
  { href: "/experts", icon: Users, label: "Experts" },
  { href: "/achievements", icon: Trophy, label: "Achievements" },
  { href: "/settings", icon: Settings, label: "Settings" },
  { href: "/billing", icon: CreditCard, label: "Billing" },
]

export function DashboardSidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-64 glass border-r border-white/5 flex flex-col">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-nova-gradient flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <span className="font-bold text-lg gradient-text">Nova AI</span>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        {navItems.map((item) => {
          const isActive = pathname === item.href
          const Icon = item.icon

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 relative",
                isActive
                  ? "bg-nova-blue/10 text-nova-blue border border-nova-blue/20"
                  : "text-white/60 hover:text-white hover:bg-white/5"
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
              {isActive && (
                <motion.div
                  layoutId="activeNav"
                  className="absolute left-0 w-1 h-8 bg-nova-blue rounded-r-full"
                />
              )}
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t border-white/5">
        <button className="flex items-center gap-3 px-4 py-3 text-white/60 hover:text-red-400 transition-colors w-full">
          <LogOut className="w-5 h-5" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  )
}
